#include <torch/extension.h>

#include <torch/extension.h>
void streamattn_temporal_out_cuda(
    torch::Tensor q, torch::Tensor k, torch::Tensor v,
    torch::Tensor partial_o, torch::Tensor partial_lse, torch::Tensor output,
    int64_t splits, int64_t component, int64_t protocol);
torch::Tensor streamattn_temporal_resource_info_cuda(torch::Tensor q, int64_t protocol);
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("out", &streamattn_temporal_out_cuda);
  m.def("resource_info", &streamattn_temporal_resource_info_cuda);
}
