#include <torch/extension.h>

#include <torch/extension.h>

void streamattn_transposed_wgmma_qk_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_cache,
    torch::Tensor scores,
    int64_t num_splits);

void streamattn_transposed_wgmma_qk_checksum_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_cache,
    torch::Tensor checksums,
    int64_t num_splits);

void streamattn_transposed_wgmma_qk_async_checksum_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_cache,
    torch::Tensor checksums,
    int64_t num_splits);

void streamattn_transposed_wgmma_qkpv_async_checksum_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_cache,
    torch::Tensor v_cache,
    torch::Tensor checksums,
    int64_t num_splits);

void streamattn_transposed_wgmma_qkpv_ws_cp_async_checksum_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_cache,
    torch::Tensor v_cache,
    torch::Tensor checksums,
    int64_t num_splits,
    int64_t consumer_registers);

torch::Tensor streamattn_transposed_wgmma_qkpv_floor_resource_info_cuda(
    int64_t consumer_registers);

void streamattn_grouped_wgmma_prefill_out_cuda(
    torch::Tensor query,
    torch::Tensor key,
    torch::Tensor value,
    torch::Tensor output,
    torch::Tensor lse);

torch::Tensor streamattn_grouped_wgmma_prefill_resource_info_cuda();

void streamattn_grouped_rs_prefill_out_cuda(
    torch::Tensor query,
    torch::Tensor key,
    torch::Tensor value,
    torch::Tensor output,
    torch::Tensor lse);

torch::Tensor streamattn_grouped_rs_prefill_resource_info_cuda();

void streamattn_transposed_wgmma_exact_partial_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_cache,
    torch::Tensor v_cache,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    int64_t num_splits);

void streamattn_transposed_wgmma_micro_prefill_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_cache,
    torch::Tensor v_cache,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t num_splits);

void streamattn_natural_wgmma_micro_prefill_out_cuda(
    torch::Tensor query,
    torch::Tensor k_cache,
    torch::Tensor v_cache,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t num_splits);

void streamattn_transposed_wgmma_exact_merge_out_cuda(
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output);

void streamattn_transposed_wgmma_exact_merge_warp_out_cuda(
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output);

void streamattn_transposed_wgmma_exact_decode_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_cache,
    torch::Tensor v_cache,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t num_splits);

void streamattn_transposed_wgmma_paged_exact_decode_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_pages,
    torch::Tensor v_pages,
    torch::Tensor page_table,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t num_splits);

void streamattn_transposed_wgmma_paged_fragmented_exact_decode_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_pages,
    torch::Tensor v_pages,
    torch::Tensor page_table,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t num_splits);

void streamattn_transposed_wgmma_paged_fragmented_ragged_exact_decode_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_pages,
    torch::Tensor v_pages,
    torch::Tensor page_table,
    torch::Tensor sequence_lengths,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t num_splits);

void streamattn_transposed_wgmma_paged_fragmented_nhd_exact_decode_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_pages,
    torch::Tensor v_pages,
    torch::Tensor page_table,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t num_splits);

void streamattn_transposed_wgmma_paged_fragmented_nhd_ragged_exact_decode_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_pages,
    torch::Tensor v_pages,
    torch::Tensor page_table,
    torch::Tensor sequence_lengths,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t num_splits);

void streamattn_transposed_wgmma_paged_selected_fragmented_exact_decode_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_pages,
    torch::Tensor v_pages,
    torch::Tensor route_row_ptr,
    torch::Tensor physical_page_ids,
    torch::Tensor active_head_masks,
    torch::Tensor token_valid_masks,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t max_routes_per_row);

void streamattn_transposed_wgmma_paged_selected_fragmented_nhd_exact_decode_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_pages,
    torch::Tensor v_pages,
    torch::Tensor route_row_ptr,
    torch::Tensor physical_page_ids,
    torch::Tensor active_head_masks,
    torch::Tensor token_valid_masks,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t max_routes_per_row);

void streamattn_prepare_qhead_paged_routes64_out_cuda(
    torch::Tensor source_row_ptr,
    torch::Tensor source_atom_ids,
    torch::Tensor page_table,
    torch::Tensor sequence_lengths,
    torch::Tensor route_counts,
    torch::Tensor logical_atom_origins,
    torch::Tensor physical_page_ids,
    torch::Tensor atom_valid_masks,
    torch::Tensor active_head_masks,
    torch::Tensor token_valid_masks,
    torch::Tensor route_flags,
    torch::Tensor route_errors,
    int64_t q_heads,
    int64_t kv_heads,
    int64_t num_pages,
    int64_t max_routes_per_group);

void streamattn_transposed_wgmma_paged_dynamic_qhead_fragmented_exact_decode_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_pages,
    torch::Tensor v_pages,
    torch::Tensor page_table,
    torch::Tensor sequence_lengths,
    torch::Tensor source_row_ptr,
    torch::Tensor source_atom_ids,
    torch::Tensor route_counts,
    torch::Tensor logical_atom_origins,
    torch::Tensor physical_page_ids,
    torch::Tensor atom_valid_masks,
    torch::Tensor active_head_masks,
    torch::Tensor token_valid_masks,
    torch::Tensor route_flags,
    torch::Tensor route_errors,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t max_routes_per_group);

void streamattn_transposed_wgmma_paged_dynamic_qhead_fragmented_nhd_exact_decode_out_cuda(
    torch::Tensor q_group,
    torch::Tensor k_pages,
    torch::Tensor v_pages,
    torch::Tensor page_table,
    torch::Tensor sequence_lengths,
    torch::Tensor source_row_ptr,
    torch::Tensor source_atom_ids,
    torch::Tensor route_counts,
    torch::Tensor logical_atom_origins,
    torch::Tensor physical_page_ids,
    torch::Tensor atom_valid_masks,
    torch::Tensor active_head_masks,
    torch::Tensor token_valid_masks,
    torch::Tensor route_flags,
    torch::Tensor route_errors,
    torch::Tensor partial_o,
    torch::Tensor partial_lse,
    torch::Tensor output,
    int64_t max_routes_per_group);

void streamattn_natural_wgmma_micro_prefill_components_out_cuda(
    torch::Tensor query, torch::Tensor k_cache, torch::Tensor v_cache,
    torch::Tensor partial_o, torch::Tensor partial_lse, torch::Tensor output,
    int64_t num_splits, int64_t component);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
  m.def("qk_out", &streamattn_transposed_wgmma_qk_out_cuda,
        "StreamAttn transposed m64n8k16 exact QK (out variant)");
  m.def("qk_checksum_out", &streamattn_transposed_wgmma_qk_checksum_out_cuda,
        "StreamAttn transposed m64n8k16 exact QK (storeless checksum variant)");
  m.def("qk_async_checksum_out", &streamattn_transposed_wgmma_qk_async_checksum_out_cuda,
        "StreamAttn transposed m64n8k16 exact QK (cp.async double-buffer checksum variant)");
  m.def("qkpv_async_checksum_out", &streamattn_transposed_wgmma_qkpv_async_checksum_out_cuda,
        "StreamAttn transposed m64n8k16 QK+PV floor (cp.async checksum variant)");
  m.def("qkpv_ws_cp_async_checksum_out",
        &streamattn_transposed_wgmma_qkpv_ws_cp_async_checksum_out_cuda,
        "StreamAttn transposed QK+PV floor (warp-specialized cp.async)");
  m.def("qkpv_floor_resource_info",
        &streamattn_transposed_wgmma_qkpv_floor_resource_info_cuda,
        "Compiled resources for cooperative and warp-specialized QK+PV floors");
  m.def("grouped_wgmma_prefill_out",
        &streamattn_grouped_wgmma_prefill_out_cuda,
        "StreamAttn natural m64n64 grouped exact causal prefill");
  m.def("grouped_wgmma_prefill_resource_info",
        &streamattn_grouped_wgmma_prefill_resource_info_cuda,
        "Compiled resources for natural m64n64 grouped exact causal prefill");
  m.def("grouped_rs_prefill_out",
        &streamattn_grouped_rs_prefill_out_cuda,
        "StreamAttn consumer-owned cp.async SS-QK/RS-PV exact causal prefill");
  m.def("grouped_rs_prefill_resource_info",
        &streamattn_grouped_rs_prefill_resource_info_cuda,
        "Compiled resources for consumer-owned grouped RS-PV prefill");
  m.def("exact_partial_out", &streamattn_transposed_wgmma_exact_partial_out_cuda,
        "StreamAttn transposed m64n8k16 exact attention partial states");
  m.def("micro_prefill_out", &streamattn_transposed_wgmma_micro_prefill_out_cuda,
        "StreamAttn transposed GQA exact micro-prefill with split-state merge");
  m.def("natural_micro_prefill_out", &streamattn_natural_wgmma_micro_prefill_out_cuda,
        "StreamAttn natural small-M GQA exact micro-prefill");
  m.def("natural_micro_prefill_components_out",
        &streamattn_natural_wgmma_micro_prefill_components_out_cuda,
        "Diagnostic natural micro-prefill: 0 combined, 1 producer, 2 merge");
  m.def("exact_merge_out", &streamattn_transposed_wgmma_exact_merge_out_cuda,
        "StreamAttn exact split-state merge");
  m.def("exact_merge_warp_out", &streamattn_transposed_wgmma_exact_merge_warp_out_cuda,
        "StreamAttn one-warp exact split-state merge");
  m.def("exact_decode_out", &streamattn_transposed_wgmma_exact_decode_out_cuda,
        "StreamAttn exact producer and merge (single host dispatch)");
  m.def("paged_exact_decode_out",
        &streamattn_transposed_wgmma_paged_exact_decode_out_cuda,
        "StreamAttn HND-paged exact producer and merge (single host dispatch)");
  m.def("paged_fragmented_exact_decode_out",
        &streamattn_transposed_wgmma_paged_fragmented_exact_decode_out_cuda,
        "StreamAttn HND page-16 fragmented exact producer and merge");
  m.def("paged_fragmented_ragged_exact_decode_out",
        &streamattn_transposed_wgmma_paged_fragmented_ragged_exact_decode_out_cuda,
        "StreamAttn HND page-16 ragged fragmented exact producer and merge");
  m.def("paged_fragmented_nhd_exact_decode_out",
        &streamattn_transposed_wgmma_paged_fragmented_nhd_exact_decode_out_cuda,
        "StreamAttn direct NHD page-16 fragmented exact producer and merge");
  m.def("paged_fragmented_nhd_ragged_exact_decode_out",
        &streamattn_transposed_wgmma_paged_fragmented_nhd_ragged_exact_decode_out_cuda,
        "StreamAttn direct NHD page-16 ragged fragmented exact producer and merge");
  m.def("paged_selected_fragmented_exact_decode_out",
        &streamattn_transposed_wgmma_paged_selected_fragmented_exact_decode_out_cuda,
        "StreamAttn HND page-16 selected-route producer and static merge");
  m.def("paged_selected_fragmented_nhd_exact_decode_out",
        &streamattn_transposed_wgmma_paged_selected_fragmented_nhd_exact_decode_out_cuda,
        "StreamAttn direct NHD page-16 selected-route producer and static merge");
  m.def("prepare_qhead_paged_routes64_out",
        &streamattn_prepare_qhead_paged_routes64_out_cuda,
        "StreamAttn device-side Q-head CSR to row-local PackedRoute64 lowering");
  m.def("paged_dynamic_qhead_fragmented_exact_decode_out",
        &streamattn_transposed_wgmma_paged_dynamic_qhead_fragmented_exact_decode_out_cuda,
        "StreamAttn HND dynamic Q-head route preparation and selected decode");
  m.def("paged_dynamic_qhead_fragmented_nhd_exact_decode_out",
        &streamattn_transposed_wgmma_paged_dynamic_qhead_fragmented_nhd_exact_decode_out_cuda,
        "StreamAttn direct NHD dynamic Q-head route preparation and selected decode");
}
